from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import httpx
from bs4 import BeautifulSoup
from datetime import datetime, timezone

app = FastAPI(title="Kharkiw Radar API")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=False,
    allow_methods=["*"], allow_headers=["*"]
)

CHANNELS = ["NochnojDozorKh", "cxidua", "monitor1654", "radarukraine777", "tlknewsua"]

@app.get("/")
async def root():
    return {"service": "Kharkiw Radar API", "status": "running"}

@app.get("/api/health")
async def health():
    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/alerts")
async def alerts():
    # Region-level alert data only. Source availability and response format may change.
    url = "https://tryvoha.online/api/v1/alerts"
    try:
        async with httpx.AsyncClient(timeout=12, follow_redirects=True) as client:
            r = await client.get(url)
            r.raise_for_status()
            data = r.json()
        return {"source": "tryvoha.online", "data": data, "note": "Informational source; verify with official alerts."}
    except Exception as e:
        return {"source": "tryvoha.online", "data": None, "error": str(e)}

@app.get("/api/telegram")
async def telegram():
    result = []
    async with httpx.AsyncClient(timeout=12, follow_redirects=True,
                                 headers={"User-Agent": "Mozilla/5.0"}) as client:
        for channel in CHANNELS:
            try:
                r = await client.get(f"https://t.me/s/{channel}")
                r.raise_for_status()
                soup = BeautifulSoup(r.text, "html.parser")
                for node in soup.select(".tgme_widget_message")[-8:]:
                    body = node.select_one(".tgme_widget_message_text")
                    date = node.select_one("time")
                    link = node.select_one(".tgme_widget_message_date")
                    if not body:
                        continue
                    href = link.get("href") if link else f"https://t.me/{channel}"
                    result.append({
                        "channel": channel,
                        "text": body.get_text(" ", strip=True),
                        "time": date.get("datetime") if date else None,
                        "url": href
                    })
            except Exception as e:
                result.append({"channel": channel, "error": str(e)})
    result.sort(key=lambda x: x.get("time") or "", reverse=True)
    return {"items": result, "note": "Public previews may be unavailable or change format."}
