const http = require('http');
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.BOT_TOKEN;
const CHANNEL = (process.env.CHANNEL_USERNAME || 'radarukraine777').replace(/^@/, '').toLowerCase();
const PORT = Number(process.env.PORT || 3000);
const posts = [];
let offset = 0;
let polling = false;

if (!TOKEN) {
  console.error('Не задан BOT_TOKEN. Создайте .env по образцу .env.example');
  process.exit(1);
}

function telegramLink(chat, messageId) {
  if (chat.username) return `https://t.me/${chat.username}/${messageId}`;
  return null;
}

async function pollTelegram() {
  if (polling) return;
  polling = true;
  try {
    const url = `https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=25&offset=${offset}&allowed_updates=%5B%22channel_post%22%5D`;
    const response = await fetch(url);
    const data = await response.json();
    if (!data.ok) throw new Error(data.description || 'Telegram API error');

    for (const update of data.result || []) {
      offset = Math.max(offset, update.update_id + 1);
      const msg = update.channel_post;
      if (!msg || !msg.chat) continue;
      const username = (msg.chat.username || '').toLowerCase();
      if (username !== CHANNEL) continue;

      const text = msg.text || msg.caption || '';
      posts.push({
        id: msg.message_id,
        date: msg.date,
        text: text.slice(0, 5000),
        link: telegramLink(msg.chat, msg.message_id)
      });
      if (posts.length > 100) posts.shift();
    }
  } catch (error) {
    console.error('Ошибка получения публикаций:', error.message);
    await new Promise(resolve => setTimeout(resolve, 4000));
  } finally {
    polling = false;
  }
  setImmediate(pollTelegram);
}

const server = http.createServer((req, res) => {
  if (req.url === '/api/posts') {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(JSON.stringify(posts));
    return;
  }

  const pathname = req.url === '/' ? '/index.html' : decodeURIComponent(req.url.split('?')[0]);
  const filePath = path.join(__dirname, 'public', pathname.replace(/^\/+/, ''));
  if (!filePath.startsWith(path.join(__dirname, 'public'))) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (error, content) => {
    if (error) { res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(filePath);
    const type = ext === '.html' ? 'text/html; charset=utf-8' :
                 ext === '.css' ? 'text/css' :
                 ext === '.js' ? 'text/javascript' : 'application/octet-stream';
    res.writeHead(200, {'Content-Type': type});
    res.end(content);
  });
});

server.listen(PORT, () => {
  console.log(`Kharkiw Radar запущен: http://localhost:${PORT}`);
  pollTelegram();
});
